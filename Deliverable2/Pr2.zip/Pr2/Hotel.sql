-- Table: public.Hotel

-- DROP TABLE IF EXISTS public."Hotel";

CREATE TABLE IF NOT EXISTS public."Hotel"
(
    "hotelID" integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    address "char" NOT NULL,
    phone_num integer NOT NULL,
    num_of_rooms integer NOT NULL,
    email "char" NOT NULL,
    rating integer NOT NULL,
    CONSTRAINT "Hotel_pkey" PRIMARY KEY ("hotelID"),
    CONSTRAINT rating CHECK (rating::text = ANY (ARRAY['one'::character varying::text, 'two'::character varying::text, 'three'::character varying::text, 'four'::character varying::text, 'five'::character varying::text])) NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Hotel"
    OWNER to postgres;