-- Table: public.Employees

-- DROP TABLE IF EXISTS public."Employees";

CREATE TABLE IF NOT EXISTS public."Employees"
(
    "SIN" integer NOT NULL,
    role "char" NOT NULL,
    full_name "char" NOT NULL,
    address "char",
    CONSTRAINT "Employees_pkey" PRIMARY KEY ("SIN"),
    CONSTRAINT role CHECK (role::text = ANY (ARRAY['manager'::character varying::text, 'staff'::character varying::text, 'cleaner'::character varying::text])) NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Employees"
    OWNER to postgres;