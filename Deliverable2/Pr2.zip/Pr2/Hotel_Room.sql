-- Table: public.Hotel_Room

-- DROP TABLE IF EXISTS public."Hotel_Room";

CREATE TABLE IF NOT EXISTS public."Hotel_Room"
(
    price integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    views "char" NOT NULL,
    extendable boolean NOT NULL,
    damages "char",
    "room_ID" integer NOT NULL,
    "hotel_ID" integer NOT NULL,
    amenities "char"[] NOT NULL,
    capacity "char" NOT NULL,
    CONSTRAINT "Hotel_Room_pkey" PRIMARY KEY ("room_ID"),
    CONSTRAINT price UNIQUE (price),
    CONSTRAINT room_id UNIQUE ("room_ID"),
    CONSTRAINT "hotel_ID" FOREIGN KEY ("hotel_ID")
        REFERENCES public."Hotel" ("hotelID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT views CHECK (views::text = ANY (ARRAY['Mountain'::character varying::text, 'Ocean'::character varying::text, 'City'::character varying::text])) NOT VALID,
    CONSTRAINT amenities CHECK (amenities::text = ANY (ARRAY['Fridge'::character varying::text, 'TV'::character varying::text, 'Jacuzzi'::character varying::text, 'Wifi'::character varying::text, 'Breakfast'::character varying::text, 'Pet Friendly'::character varying::text])) NOT VALID,
    CONSTRAINT capacity CHECK (capacity::text = ANY (ARRAY['single'::character varying::text, 'double'::character varying::text, 'triple'::character varying::text])) NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Hotel_Room"
    OWNER to postgres;