-- Table: public.Archive

-- DROP TABLE IF EXISTS public."Archive";

CREATE TABLE IF NOT EXISTS public."Archive"
(
    "archive_ID" integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    "hotel_ID" integer NOT NULL,
    "c_SIN" integer NOT NULL,
    "e_SIN" integer NOT NULL,
    check_in date NOT NULL,
    check_out date NOT NULL,
    price integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    CONSTRAINT "Archive_pkey" PRIMARY KEY ("archive_ID"),
    CONSTRAINT "c_SIN" FOREIGN KEY ("c_SIN")
        REFERENCES public."Customers" ("SIN") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT check_in FOREIGN KEY (check_in)
        REFERENCES public."Booking" (check_in) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT check_out FOREIGN KEY (check_out)
        REFERENCES public."Booking" (check_out) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT "e_SIN" FOREIGN KEY ("e_SIN")
        REFERENCES public."Employees" ("SIN") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "hotel_ID" FOREIGN KEY ("hotel_ID")
        REFERENCES public."Hotel" ("hotelID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT price FOREIGN KEY (price)
        REFERENCES public."Hotel_Room" (price) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Archive"
    OWNER to postgres;