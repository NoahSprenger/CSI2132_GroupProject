-- Table: public.Customers

-- DROP TABLE IF EXISTS public."Customers";

CREATE TABLE IF NOT EXISTS public."Customers"
(
    full_name "char" NOT NULL,
    address "char",
    "SIN" integer NOT NULL,
    reg_date date NOT NULL,
    CONSTRAINT "Customers_pkey" PRIMARY KEY ("SIN")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Customers"
    OWNER to postgres;