-- Table: public.Renting

-- DROP TABLE IF EXISTS public."Renting";

CREATE TABLE IF NOT EXISTS public."Renting"
(
    room_id integer NOT NULL,
    hotel_id integer NOT NULL,
    "c_SIN" integer NOT NULL,
    "e_SIN" integer,
    conf_num integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 500 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    CONSTRAINT "Renting_pkey" PRIMARY KEY (conf_num),
    CONSTRAINT "c_SIN" FOREIGN KEY ("c_SIN")
        REFERENCES public."Customers" ("SIN") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT "e_SIN" FOREIGN KEY ("e_SIN")
        REFERENCES public."Employees" ("SIN") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT "hotel_ID" FOREIGN KEY (hotel_id)
        REFERENCES public."Hotel" ("hotelID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID,
    CONSTRAINT room_id FOREIGN KEY (room_id)
        REFERENCES public."Hotel_Room" ("room_ID") MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Renting"
    OWNER to postgres;