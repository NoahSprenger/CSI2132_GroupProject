-- Table: public.Hotel Chain

-- DROP TABLE IF EXISTS public."Hotel Chain";

CREATE TABLE IF NOT EXISTS public."Hotel Chain"
(
    "chainID" integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    address "char",
    email "char",
    phonenum integer NOT NULL,
    chainname "char" NOT NULL,
    CONSTRAINT "Hotel Chain_pkey" PRIMARY KEY ("chainID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Hotel Chain"
    OWNER to postgres;